
package pack_1;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpExchange;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.*;

public class WebServer {

    private static final BankSystem bank = new BankSystem();

    private static final Map<String, User> sessions =
            new ConcurrentHashMap<>();

    private static final Path FRONTEND =
            Paths.get("src", "pack_1", "frontend", "public")
                    .toAbsolutePath().normalize();

    public static void main(String[] args) throws Exception {

        FileHandler.restoreSystem(bank);

        HttpServer server = HttpServer.create(
                new InetSocketAddress(8080), 0);

        server.createContext("/", WebServer::handleRequest);
        server.setExecutor(null);
        server.start();

        System.out.println("================================");
        System.out.println("ROYAL BANK SERVER STARTED");
        System.out.println("Website: http://localhost:8080");
        System.out.println("API: http://localhost:8080/api/health");
        System.out.println("================================");
    }

    private static void handleRequest(HttpExchange ex)
            throws IOException {

        ex.getResponseHeaders().set(
                "Access-Control-Allow-Origin", "*");

        ex.getResponseHeaders().set(
                "Access-Control-Allow-Methods",
                "GET, POST, OPTIONS");

        ex.getResponseHeaders().set(
                "Access-Control-Allow-Headers",
                "Content-Type, Authorization");

        if (ex.getRequestMethod().equals("OPTIONS")) {
            ex.sendResponseHeaders(204, -1);
            ex.close();
            return;
        }

        try {
            String path = ex.getRequestURI().getPath();
            String method = ex.getRequestMethod();

            if (path.startsWith("/api/")) {
                handleAPI(ex, path, method);
            } else {
                serveFrontend(ex, path);
            }

        } catch (Exception e) {
            e.printStackTrace();
            sendJson(ex, 500,
                    "{\"success\":false,\"message\":\"Internal server error\"}");
        }
    }

    // ================= FRONTEND =================

    private static void serveFrontend(
            HttpExchange ex, String requestedPath)
            throws IOException {

        String fileName = requestedPath.equals("/")
                ? "index.html"
                : requestedPath.substring(1);

        Path file = FRONTEND.resolve(fileName).normalize();

        if (!file.startsWith(FRONTEND) ||
                !Files.exists(file) ||
                Files.isDirectory(file)) {

            sendJson(ex, 404,
                    "{\"success\":false,\"message\":\"Page not found\"}");
            return;
        }

        String type = "text/plain";

        if (fileName.endsWith(".html"))
            type = "text/html";
        else if (fileName.endsWith(".css"))
            type = "text/css";
        else if (fileName.endsWith(".js"))
            type = "application/javascript";
        else if (fileName.endsWith(".png"))
            type = "image/png";
        else if (fileName.endsWith(".jpg") ||
                 fileName.endsWith(".jpeg"))
            type = "image/jpeg";
        else if (fileName.endsWith(".svg"))
            type = "image/svg+xml";

        byte[] data = Files.readAllBytes(file);

        ex.getResponseHeaders().set(
                "Content-Type", type + "; charset=UTF-8");

        ex.sendResponseHeaders(200, data.length);

        try (OutputStream os = ex.getResponseBody()) {
            os.write(data);
        }
    }

    // ================= API ROUTES =================

    private static void handleAPI(
            HttpExchange ex, String path, String method)
            throws Exception {

        if (path.equals("/api/health")) {
            sendJson(ex, 200,
                    "{\"success\":true,\"status\":\"running\"}");
            return;
        }

        String body = readBody(ex);

        // REGISTER
        if (path.equals("/api/register") && method.equals("POST")) {

            Customer c = bank.registerCustomer(
                    getString(body, "username"),
                    getString(body, "password"),
                    getString(body, "email"),
                    getString(body, "phone"),
                    getString(body, "fullName"),
                    getString(body, "address"),
                    getString(body, "nationalId")
            );

            sendJson(ex, 201,
                    "{\"success\":true,\"message\":\"Registration successful\","
                    + "\"userId\":\"" + escape(c.getUserId()) + "\"}");
            return;
        }

        // LOGIN
        if (path.equals("/api/login") && method.equals("POST")) {

            User user = bank.login(
                    getString(body, "username"),
                    getString(body, "password")
            );

            String token = UUID.randomUUID().toString();
            sessions.put(token, user);

            sendJson(ex, 200,
                    "{\"success\":true,"
                    + "\"token\":\"" + token + "\","
                    + "\"user\":" + userJson(user) + "}");
            return;
        }

        // AUTHENTICATION
        User user = authenticate(ex);

        if (user == null) {
            sendJson(ex, 401,
                    "{\"success\":false,\"message\":\"Please login first\"}");
            return;
        }

        if (path.equals("/api/logout") && method.equals("POST")) {
            sessions.remove(getToken(ex));
            sendJson(ex, 200,
                    "{\"success\":true,\"message\":\"Logged out\"}");
            return;
        }

        if (path.equals("/api/me") && method.equals("GET")) {
            sendJson(ex, 200,
                    "{\"success\":true,\"user\":" + userJson(user) + "}");
            return;
        }

        if (path.equals("/api/bills") && method.equals("GET")) {
            sendJson(ex, 200,
                    "{\"success\":true,\"bills\":"
                    + billsJson() + "}");
            return;
        }

        if (!(user instanceof Customer)) {
            sendJson(ex, 403,
                    "{\"success\":false,\"message\":\"Customer access required\"}");
            return;
        }

        Customer customer = (Customer) user;

        if (path.equals("/api/dashboard") && method.equals("GET")) {
            sendJson(ex, 200, dashboardJson(customer));
            return;
        }

        String account = getString(body, "accountNumber");
        double amount = getDouble(body, "amount");

        // DEPOSIT
        if (path.equals("/api/deposit") && method.equals("POST")) {
            bank.deposit(customer, account, amount);
            success(ex, "Deposit successful");
            return;
        }

        // WITHDRAW
        if (path.equals("/api/withdraw") && method.equals("POST")) {
            bank.withdraw(customer, account, amount);
            success(ex, "Withdrawal successful");
            return;
        }

        // TRANSFER
        if (path.equals("/api/transfer") && method.equals("POST")) {
            bank.transfer(customer,
                    account,
                    getString(body, "toAccount"),
                    amount);
            success(ex, "Transfer successful");
            return;
        }

        // OPEN ACCOUNT
        if (path.equals("/api/open-account") && method.equals("POST")) {
            Account a = bank.openAccount(
                    customer,
                    getString(body, "accountType"),
                    amount,
                    (int) getDouble(body, "fdMonths")
            );

            sendJson(ex, 200,
                    "{\"success\":true,\"message\":\"Account opened\","
                    + "\"accountNumber\":\""
                    + escape(a.getAccountNumber()) + "\"}");
            return;
        }

        // APPLY LOAN
        if (path.equals("/api/apply-loan") && method.equals("POST")) {
            bank.applyLoan(customer, account, amount);
            success(ex, "Loan application successful");
            return;
        }

        // REPAY LOAN
        if (path.equals("/api/repay-loan") && method.equals("POST")) {
            bank.repayLoan(customer, account, amount);
            success(ex, "Loan repayment successful");
            return;
        }

        // PAY BILL
        if (path.equals("/api/pay-bill") && method.equals("POST")) {
            bank.payBill(customer, account,
                    getString(body, "billType"));
            success(ex, "Bill payment successful");
            return;
        }

        sendJson(ex, 404,
                "{\"success\":false,\"message\":\"API endpoint not found\"}");
    }

    // ================= AUTHENTICATION =================

    private static String getToken(HttpExchange ex) {
        String header = ex.getRequestHeaders()
                .getFirst("Authorization");

        if (header == null || !header.startsWith("Bearer "))
            return "";

        return header.substring(7).trim();
    }

    private static User authenticate(HttpExchange ex) {
        return sessions.get(getToken(ex));
    }

    // ================= JSON RESPONSES =================

    private static String userJson(User u) {

        return "{"
                + "\"userId\":\"" + escape(u.getUserId()) + "\","
                + "\"username\":\"" + escape(u.getUsername()) + "\","
                + "\"fullName\":\""
                + escape(u instanceof Customer
                    ? ((Customer) u).getFullName()
                    : u.getUsername()) + "\","
                + "\"email\":\"" + escape(u.getEmail()) + "\","
                + "\"phone\":\"" + escape(u.getPhone()) + "\","
                + "\"role\":\"" + escape(u.getRole()) + "\""
                + "}";
    }

    private static String dashboardJson(Customer c) {

        StringBuilder json = new StringBuilder();

        json.append("{\"success\":true,");
        json.append("\"user\":").append(userJson(c)).append(",");
        json.append("\"loanBalance\":").append(c.getLoanBalance()).append(",");
        json.append("\"loanActive\":").append(c.isLoanActive()).append(",");
        json.append("\"accounts\":[");

        List<Account> accounts = c.getAccounts();

        for (int i = 0; i < accounts.size(); i++) {
            Account a = accounts.get(i);

            if (i > 0) json.append(",");

            json.append("{")
                    .append("\"accountNumber\":\"")
                    .append(escape(a.getAccountNumber())).append("\",")
                    .append("\"accountType\":\"")
                    .append(escape(a.getAccountType())).append("\",")
                    .append("\"balance\":").append(a.getBalance()).append(",")
                    .append("\"active\":").append(a.isActive())
                    .append("}");
        }

        json.append("],\"transactions\":[");

        boolean first = true;

        for (Account a : accounts) {
            for (Transaction t : a.getTransactions()) {

                if (!first) json.append(",");
                first = false;

                json.append("{")
                        .append("\"type\":\"").append(escape(t.getType())).append("\",")
                        .append("\"amount\":").append(t.getAmount()).append(",")
                        .append("\"description\":\"")
                        .append(escape(t.getDescription())).append("\",")
                        .append("\"accountNumber\":\"")
                        .append(escape(t.getAccountNumber())).append("\",")
                        .append("\"timestamp\":\"")
                        .append(escape(t.getTimestamp())).append("\"")
                        .append("}");
            }
        }

        json.append("]}");
        return json.toString();
    }

    private static String billsJson() {
        StringBuilder result = new StringBuilder("{");
        boolean first = true;

        for (Map.Entry<String, Double> entry :
                BankSystem.getBills().entrySet()) {

            if (!first) result.append(",");
            first = false;

            result.append("\"")
                    .append(escape(entry.getKey()))
                    .append("\":")
                    .append(entry.getValue());
        }

        return result.append("}").toString();
    }

    // ================= UTILITIES =================

    private static String readBody(HttpExchange ex)
            throws IOException {

        return new String(
                ex.getRequestBody().readAllBytes(),
                StandardCharsets.UTF_8);
    }

    private static String getString(String json, String key) {

        Pattern pattern = Pattern.compile(
                "\"" + Pattern.quote(key)
                + "\"\\s*:\\s*\"((?:\\\\.|[^\"\\\\])*)\"");

        Matcher matcher = pattern.matcher(json);

        if (!matcher.find()) return "";

        return matcher.group(1)
                .replace("\\\"", "\"")
                .replace("\\\\", "\\")
                .replace("\\n", "\n");
    }

    private static double getDouble(String json, String key) {

        Pattern pattern = Pattern.compile(
                "\"" + Pattern.quote(key)
                + "\"\\s*:\\s*(-?\\d+(?:\\.\\d+)?)");

        Matcher matcher = pattern.matcher(json);

        if (!matcher.find()) return 0;

        return Double.parseDouble(matcher.group(1));
    }

    private static String escape(String value) {

        if (value == null) return "";

        return value.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r");
    }

    private static void success(
            HttpExchange ex, String message)
            throws IOException {

        sendJson(ex, 200,
                "{\"success\":true,\"message\":\""
                + escape(message) + "\"}");
    }

    private static void sendJson(
            HttpExchange ex, int status, String json)
            throws IOException {

        byte[] data = json.getBytes(StandardCharsets.UTF_8);

        ex.getResponseHeaders().set(
                "Content-Type", "application/json; charset=UTF-8");

        ex.sendResponseHeaders(status, data.length);

        try (OutputStream os = ex.getResponseBody()) {
            os.write(data);
        }
    }
}
