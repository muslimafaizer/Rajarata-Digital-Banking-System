package pack_1;

import java.util.*;

/**
 * BankSystem — core banking engine.
 * OOP: Encapsulation + Exception Handling + File Handling
 */
public class BankSystem {

    private List<Customer> customers;
    private List<Admin>    admins;
    private int            accCounter;
    private int            userCounter;

    private static final Map<String, Double> BILLS = new LinkedHashMap<>();
    static {
        BILLS.put("ELECTRICITY", 3500.00);
        BILLS.put("WATER",       1200.00);
        BILLS.put("INTERNET",    2999.00);
        BILLS.put("PHONE",        999.00);
        BILLS.put("INSURANCE",   5000.00);
    }

    public BankSystem() {
        this.customers   = new ArrayList<>();
        this.admins      = new ArrayList<>();
        this.accCounter  = 1000;
        this.userCounter = 100;
        // Default admin — always available
        admins.add(new Admin("ADM001", "admin", "admin123",
                "admin@dbs.lk", "0771234567", "Operations", 5));
    }

    // ── REGISTER ─────────────────────────────────────────────────────────

    public Customer registerCustomer(String username, String password, String email,
                                     String phone,    String fullName,
                                     String address,  String nationalId)
            throws BankingException {

        if (findUserByUsername(username) != null)
            throw new BankingException("Username '" + username + "' is already taken.");
        if (username.trim().isEmpty())
            throw new BankingException("Username cannot be empty.");
        if (password.length() < 6)
            throw new BankingException("Password must be at least 6 characters.");
        if (!email.contains("@") || !email.contains("."))
            throw new BankingException("Invalid email address.");
        if (phone.trim().isEmpty())
            throw new BankingException("Phone number cannot be empty.");

        String   cid      = "CUS" + (++userCounter);
        Customer customer = new Customer(cid, username, password,
                                         email, phone, fullName, address, nationalId);

        // Auto-open a Savings account on registration
        String         accNum  = generateAccNum("SAV");
        SavingsAccount savings = new SavingsAccount(accNum, cid, 0.0);
        customer.addAccount(savings);

        customers.add(customer);
        FileHandler.saveAll(customers, admins);
        return customer;
    }

    // ── LOGIN ─────────────────────────────────────────────────────────────

    public User login(String username, String password) throws BankingException {
        User user = findUserByUsername(username);
        if (user == null)
            throw new BankingException("User not found. Please register first.");
        if (!user.validatePassword(password))
            throw new BankingException("Incorrect password. Please try again.");
        return user;
    }

    // ── DEPOSIT ───────────────────────────────────────────────────────────

    public void deposit(Customer c, String accNum, double amount)
            throws BankingException {
        Account acc = requireAccount(c, accNum);
        acc.deposit(amount, "Customer deposit");
        c.addNotification("Deposited LKR " + String.format("%,.2f", amount)
                + " → " + accNum);
        FileHandler.saveAll(customers, admins);
    }

    // ── WITHDRAW ──────────────────────────────────────────────────────────

    public void withdraw(Customer c, String accNum, double amount)
            throws BankingException {
        Account acc = requireAccount(c, accNum);
        acc.withdraw(amount, "Customer withdrawal");
        c.addNotification("Withdrew LKR " + String.format("%,.2f", amount)
                + " ← " + accNum);
        FileHandler.saveAll(customers, admins);
    }

    // ── TRANSFER ──────────────────────────────────────────────────────────

    public void transfer(Customer sender, String fromNum, String toNum, double amount)
            throws BankingException {
        if (fromNum.equals(toNum))
            throw new BankingException("Cannot transfer to the same account.");

        Account from = requireAccount(sender, fromNum);
        Account to   = findAccountByNumber(toNum);
        if (to == null)
            throw new BankingException("Destination account not found: " + toNum);

        from.withdraw(amount, "Transfer to " + toNum);
        from.addTransaction(new Transaction("TRF_OUT", amount,
                from.getBalance(), "Transfer to " + toNum, fromNum));

        to.deposit(amount, "Transfer from " + fromNum);
        to.addTransaction(new Transaction("TRF_IN", amount,
                to.getBalance(), "Transfer from " + fromNum, toNum));

        sender.addNotification("Transferred LKR " + String.format("%,.2f", amount)
                + "  " + fromNum + " → " + toNum);

        Customer receiver = findCustomerByAccountNumber(toNum);
        if (receiver != null && !receiver.getUserId().equals(sender.getUserId()))
            receiver.addNotification("Received LKR " + String.format("%,.2f", amount)
                    + " from " + fromNum);

        FileHandler.saveAll(customers, admins);
    }

    // ── OPEN NEW ACCOUNT ─────────────────────────────────────────────────

    public Account openAccount(Customer c, String type,
                               double initialDeposit, int fdMonths)
            throws BankingException {
        if (initialDeposit < 0)
            throw new BankingException("Initial deposit cannot be negative.");

        Account acc = switch (type.toUpperCase()) {
            case "SAVINGS" -> {
                SavingsAccount sa = new SavingsAccount(
                        generateAccNum("SAV"), c.getUserId(), 0);
                if (initialDeposit > 0) sa.deposit(initialDeposit, "Account opening deposit");
                yield sa;
            }
            case "CURRENT" -> {
                CurrentAccount ca = new CurrentAccount(
                        generateAccNum("CUR"), c.getUserId(), 0);
                if (initialDeposit > 0) ca.deposit(initialDeposit, "Account opening deposit");
                yield ca;
            }
            case "FIXED" -> {
                if (initialDeposit < 10_000)
                    throw new BankingException(
                        "Fixed Deposit requires a minimum of LKR 10,000.");
                yield new FixedDepositAccount(
                        generateAccNum("FD"), c.getUserId(), initialDeposit, fdMonths);
            }
            default -> throw new BankingException("Unknown account type: " + type);
        };

        c.addAccount(acc);
        FileHandler.saveAll(customers, admins);
        return acc;
    }

    // ── LOAN ─────────────────────────────────────────────────────────────

    public void applyLoan(Customer c, String accNum, double amount)
            throws BankingException {
        if (amount <= 0 || amount > 1_000_000)
            throw new BankingException(
                "Loan amount must be between LKR 1 and LKR 1,000,000.");
        if (c.isLoanActive())
            throw new BankingException("You already have an active loan.");

        Account acc = requireAccount(c, accNum);
        c.applyForLoan(amount);
        acc.deposit(amount, "Loan disbursement");
        acc.addTransaction(new Transaction("DEP", amount,
                acc.getBalance(), "Loan disbursement", accNum));
        FileHandler.saveAll(customers, admins);
    }

    public void repayLoan(Customer c, String accNum, double amount)
            throws BankingException {
        if (!c.isLoanActive())
            throw new BankingException("You have no active loan to repay.");
        if (amount > c.getLoanBalance())
            throw new BankingException("Amount exceeds outstanding loan balance: LKR "
                    + String.format("%,.2f", c.getLoanBalance()));

        Account acc = requireAccount(c, accNum);
        acc.withdraw(amount, "Loan repayment");
        acc.addTransaction(new Transaction("LOAN_REP", amount,
                acc.getBalance(), "Loan repayment", accNum));
        c.repayLoan(amount);
        FileHandler.saveAll(customers, admins);
    }

    // ── BILL PAYMENT ──────────────────────────────────────────────────────

    public static Map<String, Double> getBills() { return BILLS; }

    public void payBill(Customer c, String accNum, String billType)
            throws BankingException {
        String key = billType.toUpperCase().trim();
        if (!BILLS.containsKey(key))
            throw new BankingException("Unknown bill type: " + billType
                    + ". Valid: " + BILLS.keySet());

        double amount = BILLS.get(key);
        Account acc   = requireAccount(c, accNum);
        acc.withdraw(amount, "Bill payment: " + key);
        acc.addTransaction(new Transaction("BILL", amount,
                acc.getBalance(), "Bill: " + key, accNum));
        c.addNotification("Paid " + key + " bill: LKR " + String.format("%,.2f", amount));
        FileHandler.saveAll(customers, admins);
    }

    // ── HELPERS ───────────────────────────────────────────────────────────

    private Account requireAccount(Customer c, String accNum)
            throws BankingException {
        Account acc = c.getAccountByNumber(accNum);
        if (acc == null)
            throw new BankingException("Account not found: " + accNum);
        if (!acc.isActive())
            throw new BankingException("Account is inactive: " + accNum);
        return acc;
    }

    private String generateAccNum(String prefix) {
        return prefix + String.format("%07d", ++accCounter);
    }

    // ── FINDERS ───────────────────────────────────────────────────────────

    public User findUserByUsername(String username) {
        for (Customer c : customers) if (c.getUsername().equals(username)) return c;
        for (Admin    a : admins)    if (a.getUsername().equals(username)) return a;
        return null;
    }

    public Customer findCustomerById(String id) {
        for (Customer c : customers) if (c.getUserId().equals(id)) return c;
        return null;
    }

    public Account findAccountByNumber(String num) {
        for (Customer c : customers)
            for (Account a : c.getAccounts())
                if (a.getAccountNumber().equals(num)) return a;
        return null;
    }

    public Customer findCustomerByAccountNumber(String num) {
        for (Customer c : customers)
            for (Account a : c.getAccounts())
                if (a.getAccountNumber().equals(num)) return c;
        return null;
    }

    // Used by FileHandler to rebuild state
    public void addCustomerDirect(Customer c) { customers.add(c); }
    public void addAdminDirect(Admin a)       { admins.add(a); }

    public List<Customer> getCustomers() { return customers; }
    public List<Admin>    getAdmins()    { return admins; }
}