package pack_1;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * FixedDepositAccount — high interest, locked for a fixed term.
 * OOP: Inheritance + Polymorphism (early withdrawal penalty)
 */
public class FixedDepositAccount extends Account {

    private static final double INTEREST_RATE = 7.5;

    private LocalDate maturityDate;
    private boolean   matured;

    public FixedDepositAccount(String accountNumber, String ownerId,
                               double initialBalance, int termMonths) {
        super(accountNumber, ownerId, initialBalance, "FIXED_DEPOSIT");
        this.maturityDate = LocalDate.now().plusMonths(termMonths);
        this.matured      = false;
    }

    @Override
    public double getInterestRate() { return INTEREST_RATE; }

    @Override
    public String getAccountFeatures() {
        return "Interest: 7.5% p.a. | Locked until: "
             + maturityDate.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"))
             + " | Early withdrawal: 2% penalty";
    }

    @Override
    protected void checkWithdrawalLimit(double amount) throws BankingException {
        if (LocalDate.now().isBefore(maturityDate)) {
            System.out.println("  ⚠  WARNING: Early withdrawal before maturity date.");
            System.out.printf("     2%% penalty applied: LKR %.2f deducted.%n", amount * 0.02);
            // Penalty is informational — actual deduction happens via extra withdraw call in BankSystem
        } else {
            matured = true;
        }
    }

    public boolean    isMatured()      { return matured || !LocalDate.now().isBefore(maturityDate); }
    public LocalDate  getMaturityDate(){ return maturityDate; }
}