package pack_1;


import java.io.*;
import java.util.*;

/**
 * FileHandler — reads and writes users.txt, accounts.txt, transactions.txt.
 * OOP: File Handling (required for marks)
 */
public class FileHandler {

    private static final String DATA_DIR  = "data/";
    public  static final String USERS_FILE = DATA_DIR + "users.txt";
    public  static final String ACCS_FILE  = DATA_DIR + "accounts.txt";
    public  static final String TXNS_FILE  = DATA_DIR + "transactions.txt";

    static {
        new File(DATA_DIR).mkdirs(); // create data/ folder automatically
    }

    // ── SAVE ─────────────────────────────────────────────────────────────

    public static void saveAllUsers(List<Customer> customers, List<Admin> admins) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(USERS_FILE))) {
            for (Customer c : customers) bw.write(c.toFileString() + "\n");
            for (Admin    a : admins)    bw.write(a.toFileString() + "\n");
            System.out.println("  [✓] users.txt saved.");
        } catch (IOException e) {
            System.err.println("  [ERROR] Saving users: " + e.getMessage());
        }
    }

    public static void saveAllAccounts(List<Customer> customers) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ACCS_FILE))) {
            for (Customer c   : customers)
                for (Account a : c.getAccounts())
                    bw.write(a.toFileString() + "\n");
            System.out.println("  [✓] accounts.txt saved.");
        } catch (IOException e) {
            System.err.println("  [ERROR] Saving accounts: " + e.getMessage());
        }
    }

    public static void saveAllTransactions(List<Customer> customers) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(TXNS_FILE))) {
            for (Customer c   : customers)
                for (Account a : c.getAccounts())
                    for (Transaction t : a.getTransactions())
                        bw.write(t.toFileString() + "\n");
            System.out.println("  [✓] transactions.txt saved.");
        } catch (IOException e) {
            System.err.println("  [ERROR] Saving transactions: " + e.getMessage());
        }
    }

    public static void saveAll(List<Customer> customers, List<Admin> admins) {
        saveAllUsers(customers, admins);
        saveAllAccounts(customers);
        saveAllTransactions(customers);
    }

    // ── LOAD ─────────────────────────────────────────────────────────────

    private static List<String[]> readLines(String filePath) {
        List<String[]> result = new ArrayList<>();
        File f = new File(filePath);
        if (!f.exists()) return result;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) result.add(line.split("\\|", -1));
            }
        } catch (IOException e) {
            System.err.println("  [ERROR] Reading " + filePath + ": " + e.getMessage());
        }
        return result;
    }

    // ── RESTORE SYSTEM ────────────────────────────────────────────────────

    public static void restoreSystem(BankSystem bank) {
        List<String[]> userLines = readLines(USERS_FILE);
        List<String[]> acctLines = readLines(ACCS_FILE);

        // 1. Restore users
        for (String[] p : userLines) {
            try {
                String role = p[5];
                if ("CUSTOMER".equals(role) && p.length >= 9) {
                    Customer c = new Customer(p[0], p[1], p[2], p[3], p[4],
                            p[6], p[7], p[8]);
                    if (p.length >= 11) {
                        double  lb = Double.parseDouble(p[9]);
                        boolean la = Boolean.parseBoolean(p[10]);
                        c.setLoanBalance(lb);
                        c.setLoanActive(la);
                    }
                    bank.addCustomerDirect(c);
                } else if ("ADMIN".equals(role) && p.length >= 8) {
                    bank.addAdminDirect(new Admin(p[0], p[1], p[2], p[3], p[4],
                            p[6], Integer.parseInt(p[7])));
                }
            } catch (Exception e) {
                System.err.println("  [WARN] Skipping bad user record: " + e.getMessage());
            }
        }

        // 2. Restore accounts
        for (String[] p : acctLines) {
            try {
                String  accNum  = p[0];
                String  ownerId = p[1];
                double  balance = Double.parseDouble(p[2]);
                String  type    = p[3];

                Customer owner = bank.findCustomerById(ownerId);
                if (owner == null) continue;

                Account acc = switch (type) {
                    case "SAVINGS"       -> new SavingsAccount(accNum, ownerId, balance);
                    case "CURRENT"       -> new CurrentAccount(accNum, ownerId, balance);
                    case "FIXED_DEPOSIT" -> new FixedDepositAccount(accNum, ownerId, balance, 12);
                    default              -> new SavingsAccount(accNum, ownerId, balance);
                };
                owner.addAccount(acc);
            } catch (Exception e) {
                System.err.println("  [WARN] Skipping bad account record.");
            }
        }

        if (!userLines.isEmpty())
            System.out.println("  [✓] Data restored from files.");
    }
}