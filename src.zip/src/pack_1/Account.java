package pack_1;

import java.util.ArrayList;
import java.util.List;

/**
 * Abstract Account — base for all account types.
 * OOP: Abstraction + Encapsulation + Composition (has Transactions)
 */
public abstract class Account {

    // Encapsulation: private fields
    private String            accountNumber;
    private String            ownerId;
    private double            balance;
    private String            accountType;
    private String            dateOpened;
    private boolean           active;
    private List<Transaction> transactionHistory; // Composition

    public Account(String accountNumber, String ownerId,
                   double initialBalance, String accountType) {
        this.accountNumber      = accountNumber;
        this.ownerId            = ownerId;
        this.balance            = initialBalance;
        this.accountType        = accountType;
        this.active             = true;
        this.transactionHistory = new ArrayList<>();
        this.dateOpened = java.time.LocalDate.now()
                .format(java.time.format.DateTimeFormatter.ofPattern("dd-MM-yyyy"));
    }

    // Abstraction: subclasses must define these
    public abstract double getInterestRate();
    public abstract String getAccountFeatures();

    // ── Core Operations ──────────────────────────────────────────────────

    public synchronized void deposit(double amount, String description)
            throws BankingException {
        if (!active)        throw new BankingException("Account is inactive.");
        if (amount <= 0)    throw new BankingException("Deposit amount must be positive.");
        if (amount > 5_000_000)
            throw new BankingException("Amount exceeds single deposit limit (LKR 5,000,000).");

        balance += amount;
        transactionHistory.add(
                new Transaction("DEP", amount, balance, description, accountNumber));
    }

    public synchronized void withdraw(double amount, String description)
            throws BankingException {
        if (!active)          throw new BankingException("Account is inactive.");
        if (amount <= 0)      throw new BankingException("Amount must be positive.");
        if (amount > balance) throw new BankingException(
                "Insufficient funds. Balance: LKR " + String.format("%,.2f", balance));
        checkWithdrawalLimit(amount); // subclass hook

        balance -= amount;
        transactionHistory.add(
                new Transaction("WDR", amount, balance, description, accountNumber));
    }

    // Subclasses override to add custom withdrawal rules
    protected void checkWithdrawalLimit(double amount) throws BankingException {
        // default: no extra limit
    }

    public void addTransaction(Transaction t) {
        transactionHistory.add(t);
    }

    // ── Display ───────────────────────────────────────────────────────────

    public void printStatement() {
        System.out.println("\n  ─── Statement: " + accountNumber
                + " (" + accountType + ") ─────────────────────────────────────");
        System.out.printf("  %-14s %-11s %14s  %14s  %-30s%n",
                "Date/Time", "Type", "Amount (LKR)", "Balance (LKR)", "Description");
        System.out.println("  " + "─".repeat(80));
        if (transactionHistory.isEmpty()) {
            System.out.println("  No transactions yet.");
        } else {
            for (Transaction t : transactionHistory)
                System.out.println("  " + t.toTableRow());
        }
        System.out.println("  " + "─".repeat(80));
        System.out.printf("  Current Balance: LKR %,.2f%n", balance);
    }

    public void printInfo() {
        System.out.printf("  %-18s | %-14s | Balance: LKR %,12.2f | Rate: %.2f%%%n",
                accountNumber, accountType, balance, getInterestRate());
    }

    // ── File serialization ────────────────────────────────────────────────

    public String toFileString() {
        return accountNumber + "|" + ownerId + "|" + balance + "|"
             + accountType   + "|" + dateOpened + "|" + active;
    }

    // ── Getters / Setters ─────────────────────────────────────────────────

    public String            getAccountNumber()  { return accountNumber; }
    public String            getOwnerId()        { return ownerId; }
    public double            getBalance()        { return balance; }
    public String            getAccountType()    { return accountType; }
    public String            getDateOpened()     { return dateOpened; }
    public boolean           isActive()          { return active; }
    public List<Transaction> getTransactions()   { return transactionHistory; }

    protected void setBalance(double b)          { this.balance = b; }
    public    void setActive(boolean a)          { this.active  = a; }
}