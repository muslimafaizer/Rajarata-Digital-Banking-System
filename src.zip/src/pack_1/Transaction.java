package pack_1;


import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Represents one banking transaction.
 * OOP: Encapsulation, Composition (used inside Account)
 */
public class Transaction {
    private static final DateTimeFormatter FMT =
            DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");

    private String transactionId;
    private String type;          // DEP, WDR, TRF_OUT, TRF_IN, BILL, LOAN_REP
    private double amount;
    private double balanceAfter;
    private String description;
    private String accountNumber;
    private String timestamp;

    public Transaction(String type, double amount, double balanceAfter,
                       String description, String accountNumber) {
        this.transactionId = "TXN" + System.currentTimeMillis();
        this.type          = type;
        this.amount        = amount;
        this.balanceAfter  = balanceAfter;
        this.description   = description;
        this.accountNumber = accountNumber;
        this.timestamp     = LocalDateTime.now().format(FMT);
    }

    public String toTableRow() {
        String label = switch (type) {
            case "DEP"      -> "  Credit  ";
            case "WDR"      -> "  Debit   ";
            case "TRF_OUT"  -> "  Sent    ";
            case "TRF_IN"   -> "  Received";
            case "BILL"     -> "  Bill Pay";
            case "LOAN_REP" -> "  Loan Rep";
            default         -> "  " + type;
        };
        return String.format("%-14s %-11s %,12.2f  %,12.2f  %-30s",
                timestamp, label, amount, balanceAfter, description);
    }

    public String toFileString() {
        return transactionId + "|" + type      + "|" + amount + "|"
             + balanceAfter  + "|" + description + "|" + accountNumber + "|" + timestamp;
    }

    // Getters
    public String getTransactionId() { return transactionId; }
    public String getType()          { return type; }
    public double getAmount()        { return amount; }
    public double getBalanceAfter()  { return balanceAfter; }
    public String getDescription()   { return description; }
    public String getAccountNumber() { return accountNumber; }
    public String getTimestamp()     { return timestamp; }
}